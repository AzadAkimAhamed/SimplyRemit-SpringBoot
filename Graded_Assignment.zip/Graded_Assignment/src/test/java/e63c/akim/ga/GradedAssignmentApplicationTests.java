package e63c.akim.ga;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GradedAssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
