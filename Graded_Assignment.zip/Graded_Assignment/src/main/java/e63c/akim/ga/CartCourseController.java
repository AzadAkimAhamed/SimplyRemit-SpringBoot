package e63c.akim.ga;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class CartCourseController {

	@Autowired
	private CartCourseRepository cartCourseRepo;

	@Autowired
	private CourseRepository courseRepo;

	@Autowired
	private MemberRepository memberRepo;
	
	@Autowired
	private OrderCourseRepository orderCourseRepo;
	 
	
	@GetMapping("/SLI_courses/cart")
	public String showCart(Model model, Principal principal) {

		// Get currently logged in user
		MemberDetails loggedInMember = (MemberDetails) SecurityContextHolder.getContext().getAuthentication()
				.getPrincipal();
		int loggedInMemberId = loggedInMember.getMember().getId();

		// Get shopping cart courses added by this user
		// *Hint: You will need to use the method we added in the CartCourseRepository
		List<CartCourse> cartCourseList = cartCourseRepo.findByMemberId(loggedInMemberId);
		
		// Add the shopping cart courses to the model
		model.addAttribute("cartCourseList", cartCourseList);
		
		// Calculate the total cost of all courses in the shopping cart
		double cartTotal = 0.0;
		
		for (int i = 0; i < cartCourseList.size(); i++) {
			
			CartCourse currentCartCourse = cartCourseList.get(i);
			
			Course course = currentCartCourse.getCourse();
			double coursePrice = course.getPrice();
			
			cartTotal += coursePrice;
		}
		
		// Add the shopping cart total to the model
		model.addAttribute("cartTotal", cartTotal);
		
		return "cart";
	}

	@PostMapping("/SLI_courses/cart/add/{id}")
	public String addToCart(@PathVariable("id") int courseId,
			Principal principal) {

		// Get currently logged in user
		MemberDetails loggedInMember = (MemberDetails) SecurityContextHolder.getContext().getAuthentication()
				.getPrincipal();
		int loggedInMemberId = loggedInMember.getMember().getId();
		
		// Check in the cartCourseRepo if course was previously added by user.
		// *Hint: we will need to write a new method in the CartCourseRepository
		CartCourse cartCourse = cartCourseRepo.findByMemberIdAndCourseId(loggedInMemberId, courseId);
		
		// if the course was previously added, then we get the quantity that was
		// previously added and increase that
		// Save the CartCourse object back to the repository
		if (cartCourse != null) {
			cartCourseRepo.save(cartCourse);
		} else {
		
		// if the course was NOT previously added,
		// then prepare the course and member objects
			Course course = courseRepo.getById(courseId);
			Member member = memberRepo.getById(loggedInMemberId);		
		
		// Create a new CartCourse object
			CartCourse newCartCourse = new CartCourse();
		
		// Set the course and member as well as the new quantity in the new CartCourse
		// object
			newCartCourse.setCourse(course);
			newCartCourse.setMember(member);
		
		// Save the new CartCourse object to the repository
			cartCourseRepo.save(newCartCourse);
		}

		return "redirect:/SLI_courses/cart";
	}

	@PostMapping("/SLI_courses/cart/update/{id}")
	public String updateCart(@PathVariable("id") int cartCourseId) {

		// Get cartCourse object by cartCourse's id
		CartCourse cartCourse = cartCourseRepo.getById(cartCourseId);
		
		// Save the cartCourse back to the cartCourseRepo
		cartCourseRepo.save(cartCourse);

		return "redirect:/SLI_courses/cart";
	}

	@GetMapping("/SLI_courses/cart/remove/{id}")
	public String removeFromCart(@PathVariable("id") int cartCourseId) {

		//Remove course from cartCourseRepo 
		cartCourseRepo.deleteById(cartCourseId);

		return "redirect:/SLI_courses/cart";
	}
	
	@PostMapping("/cart/process_order")
	public String processOrder(Model model, @RequestParam("cartTotal") double cartTotal,
		@RequestParam("memberId") int memberId, @RequestParam("orderId") String orderId,
		@RequestParam("transactionId") String transactionId) {
	     
		// Retrieve cart courses purchased	
		List<CartCourse> cartCourseList = cartCourseRepo.findByMemberId(memberId);
	     // Get member object	
		Member member = memberRepo.getById(memberId);
		
	     // Loop to iterate through all cart courses
		for(int i = 0; i < cartCourseList.size(); i++) {
			// Retrieve details about current cart course	
			CartCourse currentCartCourse = cartCourseList.get(i);
			Course courseToUpdate = currentCartCourse.getCourse();
			int courseToUpdateId = courseToUpdate.getCourse_id();
			
			System.out.println("Course: " + courseToUpdate.getCourse_description());
			
			// Add course to order table	
			OrderCourse orderCourse = new OrderCourse();
			orderCourse.setOrderId(orderId);
			orderCourse.setTransactionId(transactionId);
			orderCourse.setCourse(courseToUpdate);
			orderCourse.setMember(member);
			orderCourseRepo.save(orderCourse);
			
			// clear cart courses belonging to member
			cartCourseRepo.deleteById(currentCartCourse.getId());
		}
		// Pass info to view to display success page
		model.addAttribute("cartTotal", cartTotal);
		model.addAttribute("cartCourseList", cartCourseList);
		model.addAttribute("member", member);
		model.addAttribute("orderId", orderId);
		model.addAttribute("transactionId", transactionId);
		
		// Send email
		return "success";
	}
	
}
