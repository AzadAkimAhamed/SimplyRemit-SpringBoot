package e63c.akim.ga;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GradedAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(GradedAssignmentApplication.class, args);
	}

}
