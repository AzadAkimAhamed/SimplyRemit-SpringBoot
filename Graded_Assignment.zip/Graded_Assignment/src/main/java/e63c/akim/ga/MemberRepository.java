/**
 * 
 * I declare that this code was written by me, 21016458. 
 * I will not copy or allow others to copy my code. 
 * I understand that copying code is considered as plagiarism.
 * 
 * Student Name: Azad Akim Ahamed
 * Student ID: 21016458
 * Class: E63C
 * Date created: 2023-Jan-03 4:24:18 pm 
 * 
 */

package e63c.akim.ga;

import org.springframework.data.jpa.repository.JpaRepository;
/**
 * @author 21016458
 *
 */
public interface MemberRepository extends JpaRepository<Member, Integer>{
	
	public Member findByUsername(String username);
}
