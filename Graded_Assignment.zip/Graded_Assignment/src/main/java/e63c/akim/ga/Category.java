/**
 * 
 * I declare that this code was written by me, 21016458. 
 * I will not copy or allow others to copy my code. 
 * I understand that copying code is considered as plagiarism.
 * 
 * Student Name: Azad Akim Ahamed
 * Student ID: 21016458
 * Class: E63C
 * Date created: 2022-Nov-18 8:13:55 am 
 * 
 */

package e63c.akim.ga;

/**
 * @author 21016458
 *
 */
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import java.util.Set;

@Entity
public class Category {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int category_id;
	
	@NotNull
	@NotEmpty(message="Category name cannot be empty!")
	@Size(min=3, max=25, message="Category name must be between 3 and 20 characters!")
	private String category_name;
	
	@OneToMany(mappedBy="category")
	private Set<Course> course;
	//To generate getters and setters, right-click empty space
	// select source and generate getters and setters (click Select All and Generate)

	/**
	 * @return the category_id
	 */
	public int getCategory_id() {
		return category_id;
	}

	/**
	 * @param category_id the category_id to set
	 */
	public void setCategory_id(int category_id) {
		this.category_id = category_id;
	}

	/**
	 * @return the category_name
	 */
	public String getCategory_name() {
		return category_name;
	}

	/**
	 * @param category_name the category_name to set
	 */
	public void setCategory_name(String category_name) {
		this.category_name = category_name;
	}
	
}
