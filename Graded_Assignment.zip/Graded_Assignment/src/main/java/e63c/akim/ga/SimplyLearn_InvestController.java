/**
 * 
 * I declare that this code was written by me, 21016458. 
 * I will not copy or allow others to copy my code. 
 * I understand that copying code is considered as plagiarism.
 * 
 * Student Name: Azad Akim Ahamed
 * Student ID: 21016458
 * Class: E63C
 * Date created: 2022-Nov-03 4:48:13 am 
 * 
 */

package e63c.akim.ga;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class SimplyLearn_InvestController {
	
	// Controller method for Homepage (Courses)
	@Autowired // connects to the database
	private CourseRepository courseRepository;
	
	@Autowired
	private CourseCategoryRepository coursecategoryRepository;
	
	@GetMapping("/SLI_courses")
	public String viewCourses(Model model) {
		List<Course> listCourses = courseRepository.findAll(); // is an API from Jpa
		List<Category> catList = coursecategoryRepository.findAll();
		List<Category> categoryList = coursecategoryRepository.findAll();
		
		model.addAttribute("catList", catList);
		model.addAttribute("listCourses", listCourses);
		model.addAttribute("categoryList", categoryList);
		
		return "Simply_Learn_Invest_Courses";
	}
	
	@GetMapping("/SLI_courses/add_course")
	public String addCourse(Model model) {
		model.addAttribute("course", new Course());
		
		List<Category> categoryList = coursecategoryRepository.findAll();
		model.addAttribute("categoryList", categoryList);
		
		return "add_course";
	}
	
	@PostMapping("/SLI_courses/save_course")
	public String saveCourse(@Valid Course course, BindingResult bindingResult, @RequestParam("courseImage") MultipartFile imgFile) {
		
		if (bindingResult.hasErrors()) {
			return "add_course";
		}
		
		String courseImage = imgFile.getOriginalFilename();
		
		// Set the image name in the course object
		course.setImage(courseImage);
		
		// Save the course obj to the db
		Course savedCourse = courseRepository.save(course);
		
		try {
			// Preparing the directory paths
			String uploadDir = "uploads/courses/" + savedCourse.getCourse_id();
			Path uploadPath = Paths.get(uploadDir);
			System.out.println("Directory path: " + uploadPath);
			
			// Checking if the upload path exists, if not it will be created.
			if (!Files.exists(uploadPath)) {
				Files.createDirectories(uploadPath);
			}
			
			// Prepare path for file
			Path fileToCreatePath = uploadPath.resolve(courseImage);
			System.out.println("File path: " + fileToCreatePath);
			
			// Copy file to the upload location
			Files.copy(imgFile.getInputStream(), fileToCreatePath, StandardCopyOption.REPLACE_EXISTING);
			
		} catch (IOException io) {
			io.printStackTrace();
		}
		
		courseRepository.save(course);
		return "redirect:/SLI_courses";
	}
	
	//Need to do view_single_courses but for detailed page
	
	@GetMapping("/SLI_courses/edit_course/{id}")
	public String editCourses(@PathVariable("id") Integer id, Model model) {
		
		Course course = courseRepository.getById(id);
		model.addAttribute("course", course);
		List<Category> categoryList = coursecategoryRepository.findAll();
		model.addAttribute("categoryList", categoryList);
		return "edit_course";
	}
	
	@PostMapping("/SLI_courses/edit_course/{id}")
	public String saveUpdatedCourse(@PathVariable("id") Integer id, Course course, @RequestParam("courseImage") MultipartFile imgFile) {
		
	String courseImage = imgFile.getOriginalFilename();
			
			// Set the image name in the course object
		course.setImage(courseImage);
		course.setCourse_id(id);
		
		// Save the course obj to the db
		Course savedCourse = courseRepository.save(course);
		
		try {
			// Preparing the directory paths
			String uploadDir = "uploads/courses/" + savedCourse.getCourse_id();
			Path uploadPath = Paths.get(uploadDir);
			System.out.println("Directory path: " + uploadPath);
			
			// Checking if the upload path exists, if not it will be created.
			if (!Files.exists(uploadPath)) {
				Files.createDirectories(uploadPath);
			}
			
			// Prepare path for file
			Path fileToCreatePath = uploadPath.resolve(courseImage);
			System.out.println("File path: " + fileToCreatePath);
			
			// Copy file to the upload location
			Files.copy(imgFile.getInputStream(), fileToCreatePath, StandardCopyOption.REPLACE_EXISTING);
			
		} catch (IOException io) {
			io.printStackTrace();
		}
		
		
		return "redirect:/SLI_courses";
	}
	
	@GetMapping("/SLI_courses/delete_course/{id}")
	public String deleteCourse(@PathVariable("id") Integer id) {
		courseRepository.deleteById(id);
		
		return "redirect:/SLI_courses";
	}
	
	@GetMapping("/SLI_courses/add_category")
	public String addCategory(Model model) {
		model.addAttribute("category", new Category());
		
		return "add_category";
	}
	
	@PostMapping("/SLI_courses/save_category")
	public String saveCategory(@Valid Category category, BindingResult bindingResult) {
		
		if (bindingResult.hasErrors()) {
			return "add_category";
		}
		
		coursecategoryRepository.save(category);
		return "redirect:/SLI_courses";
		
	}
	
	@GetMapping("/SLI_courses/edit_category/{category_id}")
	public String editCategory(@PathVariable("category_id") Integer category_id, Model model) {
		
		Category category = coursecategoryRepository.getById(category_id);
		
		model.addAttribute("category", category);
		
		return "edit_category";
	}
	
	@PostMapping("/SLI_courses/edit_category/{category_id}")
	public String saveUpdatedCategory(@PathVariable("category_id") Integer category_id, @Valid Category category, BindingResult bindingResult) {
		
		coursecategoryRepository.save(category);
		return "redirect:/SLI_courses";
	}
	
	@GetMapping("/SLI_courses/delete_category/{category_id}")
	public String deleteCategory(@PathVariable("category_id") Integer category_id) {
		coursecategoryRepository.deleteById(category_id);
		
		return "redirect:/SLI_courses";
	}
		
	
	// Popular Courses (methods) Detailed Course Page - when the For More Details button is clicked
	// Controller (response) method for Financial Markets
	@GetMapping("/SLI_courses/{id}")
	public String view_SLI_Detailed_Course(@PathVariable("id") Integer id, Model model) { 
		
		Course course = courseRepository.getById(id);
		model.addAttribute("course", course);
		
		return "SLI_Detailed_Course"; // this is to call the html file for detailed course page
	}
	
	@GetMapping("/403")
	public String error403() {
		return "403";
	}
	

	// Courses for Kids (7yrs-15yrs old) - Not necessary to include
	
	// Controller (response) method for Box (Check Out)
	
	//GetMapping for Login
	@GetMapping("/login")
	public String login() {
		return "login";
	}
}
