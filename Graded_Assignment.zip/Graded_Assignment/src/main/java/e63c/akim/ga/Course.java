/**
 * 
 * I declare that this code was written by me, 21016458. 
 * I will not copy or allow others to copy my code. 
 * I understand that copying code is considered as plagiarism.
 * 
 * Student Name: Azad Akim Ahamed
 * Student ID: 21016458
 * Class: E63C
 * Date created: 2022-Nov-10 10:56:31 pm 
 * 
 */

package e63c.akim.ga;

/**
 * @author 21016458
 *
 */
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
public class Course {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	
	@NotNull
	@NotEmpty(message="Name cannot be empty.")
	@Size(min=3, max=35, message="Name length must be between 3 and 35 characters.")
	private String course_name;
	
	@NotNull
	@NotEmpty(message="Info cannot be empty.")
	@Size(min=10, max=50, message="Info length must be between 10 and 50 characters.")
	private String course_info;
	
	@NotNull
	@NotEmpty(message="Description cannot be empty.")
	@Size(min=25, max=120, message="Description length must be between 25 and 120 characters.")
	private String course_description;
	
	@Min(value=0, message="Price needs to be positive number.")
	private double price;
	
	@Min(value=0, message="Review needs to be a positive number.")
	private int review;
	
	@NotNull
	@NotEmpty(message="Includes cannot be empty.")
	private String includes;
	
	@NotNull
	@NotEmpty(message="Image cannot be empty.")
	private String image;
	
	@ManyToOne
	@JoinColumn(name="category_id", nullable=false)
	private Category category;
	
	public String getImage() {
		return image;
	}
	
	public void setImage(String image) {
		this.image = image;
	}
	
	/**
	 * @return the category
	 */
	public Category getCategory() {
		return category;
	}
	/**
	 * @param category the category to set
	 */
	public void setCategory(Category category) {
		this.category = category;
	}
	/**
	 * @return the course_id
	 */
	public int getCourse_id() {
		return id;
	}
	/**
	 * @param course_id the course_id to set
	 */
	public void setCourse_id(int id) {
		this.id = id;
	}
	/**
	 * @return the course_name
	 */
	public String getCourse_name() {
		return course_name;
	}
	/**
	 * @param course_name the course_name to set
	 */
	public void setCourse_name(String course_name) {
		this.course_name = course_name;
	}
	/**
	 * @return the course_info
	 */
	public String getCourse_info() {
		return course_info;
	}
	/**
	 * @param course_info the course_info to set
	 */
	public void setCourse_info(String course_info) {
		this.course_info = course_info;
	}
	/**
	 * @return the course_description
	 */
	public String getCourse_description() {
		return course_description;
	}
	/**
	 * @param course_description the course_description to set
	 */
	public void setCourse_description(String course_description) {
		this.course_description = course_description;
	}
	/**
	 * @return the price
	 */
	public double getPrice() {
		return price;
	}
	/**
	 * @param price the price to set
	 */
	public void setPrice(double price) {
		this.price = price;
	}
	/**
	 * @return the includes
	 */
	public String getIncludes() {
		return includes;
	}
	/**
	 * @param includes the includes to set
	 */
	public void setIncludes(String includes) {
		this.includes = includes;
	}
	/**
	 * @return the review
	 */
	public int getReview() {
		return review;
	}
	/**
	 * @param review the review to set
	 */
	public void setReview(int review) {
		this.review = review;
	}
	
}
