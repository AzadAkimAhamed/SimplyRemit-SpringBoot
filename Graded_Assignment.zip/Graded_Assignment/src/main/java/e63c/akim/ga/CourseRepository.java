/**
 * 
 * I declare that this code was written by me, 21016458. 
 * I will not copy or allow others to copy my code. 
 * I understand that copying code is considered as plagiarism.
 * 
 * Student Name: Azad Akim Ahamed
 * Student ID: 21016458
 * Class: E63C
 * Date created: 2022-Nov-10 11:33:34 pm 
 * 
 */

package e63c.akim.ga;

/**
 * @author 21016458
 *
 */
import org.springframework.data.jpa.repository.JpaRepository;

public interface CourseRepository extends JpaRepository<Course, Integer> {

}
