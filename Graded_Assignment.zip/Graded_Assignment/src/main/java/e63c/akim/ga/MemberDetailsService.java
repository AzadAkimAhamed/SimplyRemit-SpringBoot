/**
 * 
 * I declare that this code was written by me, 21016458. 
 * I will not copy or allow others to copy my code. 
 * I understand that copying code is considered as plagiarism.
 * 
 * Student Name: Azad Akim Ahamed
 * Student ID: 21016458
 * Class: E63C
 * Date created: 2023-Jan-06 11:35:30 am 
 * 
 */

package e63c.akim.ga;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

/**
 * @author 21016458
 *
 */
public class MemberDetailsService implements UserDetailsService {
	
	@Autowired
	private MemberRepository memberRepository;
	
	@Override
	public MemberDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		Member member = memberRepository.findByUsername(username);
		
		if (member == null) {
			throw new UsernameNotFoundException("Could not find user");
		}
	
		return new MemberDetails(member);
	}
}
