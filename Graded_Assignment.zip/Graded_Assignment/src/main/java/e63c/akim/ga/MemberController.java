/**
 * 
 * I declare that this code was written by me, 21016458. 
 * I will not copy or allow others to copy my code. 
 * I understand that copying code is considered as plagiarism.
 * 
 * Student Name: Azad Akim Ahamed
 * Student ID: 21016458
 * Class: E63C
 * Date created: 2023-Jan-03 4:27:02 pm 
 * 
 */

package e63c.akim.ga;

/**
 * @author 21016458
 *
 */

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class MemberController {
	
	@Autowired
	private MemberRepository memberRepository;
	
	@GetMapping("/SLI_courses/members")
	public String viewMembers(Model model) {

		List<Member> listMembers = memberRepository.findAll();
		model.addAttribute("listMembers", listMembers);
		return "view_members";

	}

	// add
	@GetMapping("/SLI_courses/members/add")
	public String addMember(Model model) {
		model.addAttribute("member", new Member());
		return "add_member";
	}

	@PostMapping("/SLI_courses/members/save")
	public String saveMember(Member member, RedirectAttributes redirectAttribute) {
		
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		String encodedPassword = passwordEncoder.encode(member.getPassword());
		
		member.setPassword(encodedPassword);
		member.setRole("ROLE_USER");
		
		memberRepository.save(member);
		
		redirectAttribute.addFlashAttribute("success", "Member registered!");
		
		return "redirect:/SLI_courses/members";
	}

	// edit

	@GetMapping("/SLI_courses/members/edit/{id}")
	public String editMember(@PathVariable("id") Integer id, Model model) {

		Member member = memberRepository.getById(id);
		model.addAttribute("member", member);

		return "edit_member";
	}

	@PostMapping("/SLI_courses/members/edit/{id}")
	public String saveUpdatedMember(@PathVariable("id") Integer id, Member member) {

		memberRepository.save(member);
		return "redirect:/SLI_courses/members";
	}

	// delete

	@GetMapping("/SLI_courses/members/delete/{id}")
	public String deleteMember(@PathVariable("id") Integer id) {

		memberRepository.deleteById(id);
	

		return "redirect:/SLI_courses/members";
	}
}
